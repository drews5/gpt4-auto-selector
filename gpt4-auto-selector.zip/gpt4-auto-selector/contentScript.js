function redirectToGPT4() {
  const currentURL = new URL(window.location.href);

  if (currentURL.host === 'chat.openai.com' && currentURL.searchParams.get('model') !== 'gpt-4') {
    currentURL.searchParams.set('model', 'gpt-4');
    window.location.href = currentURL.href;
  }
}

redirectToGPT4();
