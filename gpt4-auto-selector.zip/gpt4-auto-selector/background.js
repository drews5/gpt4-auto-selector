function redirectToGPT4(details) {
  const url = new URL(details.url);
  
  if (url.host === 'chat.openai.com' && url.searchParams.get('model') !== 'gpt-4') {
    url.searchParams.set('model', 'gpt-4');
    return { redirectUrl: url.href };
  }
}

chrome.webRequest.onBeforeRequest.addListener(
  redirectToGPT4,
  { urls: ['*://chat.openai.com/*'] },
  ['blocking']
);
